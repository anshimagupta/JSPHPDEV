package adapter;

import model.Automobile;
import server.AutoServer;

public class BuildAuto extends ProxyAutomobile implements UpdateAuto, CreateOption, CreateAuto, AutoServer {

}
