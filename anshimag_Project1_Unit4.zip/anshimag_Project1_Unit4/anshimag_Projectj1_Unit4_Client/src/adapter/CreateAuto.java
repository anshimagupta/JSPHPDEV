package adapter;

/**
 * Created by anshima on 6/12/15.
 */
public interface CreateAuto {
    public void buildAuto(String modelName, String fileName, String fileType);

    public void printAuto();
}
