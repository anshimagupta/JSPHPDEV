package exception;

interface FixAuto {
    String fix();
}
