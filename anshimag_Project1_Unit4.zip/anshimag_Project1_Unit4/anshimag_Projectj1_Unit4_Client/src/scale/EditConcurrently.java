package scale;


public interface EditConcurrently {
    void updateOptionPriceCon(String modelName);

    void updateOpSetNameCon(String modelName);
}
